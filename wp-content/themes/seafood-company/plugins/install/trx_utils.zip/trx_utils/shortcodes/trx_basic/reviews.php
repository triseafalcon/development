<?php

/* Theme setup section
-------------------------------------------------------------------- */
if (!function_exists('seafood_company_sc_reviews_theme_setup')) {
	add_action( 'seafood_company_action_before_init_theme', 'seafood_company_sc_reviews_theme_setup' );
	function seafood_company_sc_reviews_theme_setup() {
		add_action('seafood_company_action_shortcodes_list', 		'seafood_company_sc_reviews_reg_shortcodes');
		if (function_exists('seafood_company_exists_visual_composer') && seafood_company_exists_visual_composer())
			add_action('seafood_company_action_shortcodes_list_vc','seafood_company_sc_reviews_reg_shortcodes_vc');
	}
}



/* Shortcode implementation
-------------------------------------------------------------------- */

/*
[trx_reviews]
*/

if (!function_exists('seafood_company_sc_reviews')) {	
	function seafood_company_sc_reviews($atts, $content = null) {
		if (seafood_company_in_shortcode_blogger()) return '';
		extract(seafood_company_html_decode(shortcode_atts(array(
			// Individual params
			"align" => "right",
			// Common params
			"id" => "",
			"class" => "",
			"animation" => "",
			"css" => "",
			"top" => "",
			"bottom" => "",
			"left" => "",
			"right" => ""
		), $atts)));
		$class .= ($class ? ' ' : '') . seafood_company_get_css_position_as_classes($top, $right, $bottom, $left);
		$output = seafood_company_param_is_off(seafood_company_get_custom_option('show_sidebar_main'))
			? '<div' . ($id ? ' id="'.esc_attr($id).'"' : '') 
						. ' class="sc_reviews'
							. ($align && $align!='none' ? ' align'.esc_attr($align) : '')
							. ($class ? ' '.esc_attr($class) : '')
							. '"'
						. ($css!='' ? ' style="'.esc_attr($css).'"' : '')
						. (!seafood_company_param_is_off($animation) ? ' data-animation="'.esc_attr(seafood_company_get_animation_classes($animation)).'"' : '')
						. '>'
					. trim(seafood_company_get_reviews_placeholder())
					. '</div>'
			: '';
		return apply_filters('seafood_company_shortcode_output', $output, 'trx_reviews', $atts, $content);
	}
    add_shortcode("trx_reviews", "seafood_company_sc_reviews");
}



/* Register shortcode in the internal SC Builder
-------------------------------------------------------------------- */
if ( !function_exists( 'seafood_company_sc_reviews_reg_shortcodes' ) ) {
	//add_action('seafood_company_action_shortcodes_list', 'seafood_company_sc_reviews_reg_shortcodes');
	function seafood_company_sc_reviews_reg_shortcodes() {
	
		seafood_company_sc_map("trx_reviews", array(
			"title" => esc_html__("Reviews", 'trx_utils'),
			"desc" => wp_kses_data( __("Insert reviews block in the single post", 'trx_utils') ),
			"decorate" => false,
			"container" => false,
			"params" => array(
				"align" => array(
					"title" => esc_html__("Alignment", 'trx_utils'),
					"desc" => wp_kses_data( __("Align counter to left, center or right", 'trx_utils') ),
					"divider" => true,
					"value" => "none",
					"type" => "checklist",
					"dir" => "horizontal",
					"options" => seafood_company_get_sc_param('align')
				), 
				"top" => seafood_company_get_sc_param('top'),
				"bottom" => seafood_company_get_sc_param('bottom'),
				"left" => seafood_company_get_sc_param('left'),
				"right" => seafood_company_get_sc_param('right'),
				"id" => seafood_company_get_sc_param('id'),
				"class" => seafood_company_get_sc_param('class'),
				"animation" => seafood_company_get_sc_param('animation'),
				"css" => seafood_company_get_sc_param('css')
			)
		));
	}
}


/* Register shortcode in the VC Builder
-------------------------------------------------------------------- */
if ( !function_exists( 'seafood_company_sc_reviews_reg_shortcodes_vc' ) ) {
	//add_action('seafood_company_action_shortcodes_list_vc', 'seafood_company_sc_reviews_reg_shortcodes_vc');
	function seafood_company_sc_reviews_reg_shortcodes_vc() {
	
		vc_map( array(
			"base" => "trx_reviews",
			"name" => esc_html__("Reviews", 'trx_utils'),
			"description" => wp_kses_data( __("Insert reviews block in the single post", 'trx_utils') ),
			"category" => esc_html__('Content', 'trx_utils'),
			'icon' => 'icon_trx_reviews',
			"class" => "trx_sc_single trx_sc_reviews",
			"content_element" => true,
			"is_container" => false,
			"show_settings_on_create" => true,
			"params" => array(
				array(
					"param_name" => "align",
					"heading" => esc_html__("Alignment", 'trx_utils'),
					"description" => wp_kses_data( __("Align counter to left, center or right", 'trx_utils') ),
					"class" => "",
					"value" => array_flip(seafood_company_get_sc_param('align')),
					"type" => "dropdown"
				),
				seafood_company_get_vc_param('id'),
				seafood_company_get_vc_param('class'),
				seafood_company_get_vc_param('animation'),
				seafood_company_get_vc_param('css'),
				seafood_company_get_vc_param('margin_top'),
				seafood_company_get_vc_param('margin_bottom'),
				seafood_company_get_vc_param('margin_left'),
				seafood_company_get_vc_param('margin_right')
			)
		) );
		
		class WPBakeryShortCode_Trx_Reviews extends Seafood_Company_VC_ShortCodeSingle {}
	}
}
?>