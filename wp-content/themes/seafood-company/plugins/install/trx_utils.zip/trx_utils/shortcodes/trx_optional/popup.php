<?php

/* Theme setup section
-------------------------------------------------------------------- */
if (!function_exists('seafood_company_sc_popup_theme_setup')) {
	add_action( 'seafood_company_action_before_init_theme', 'seafood_company_sc_popup_theme_setup' );
	function seafood_company_sc_popup_theme_setup() {
		add_action('seafood_company_action_shortcodes_list', 		'seafood_company_sc_popup_reg_shortcodes');
		if (function_exists('seafood_company_exists_visual_composer') && seafood_company_exists_visual_composer())
			add_action('seafood_company_action_shortcodes_list_vc','seafood_company_sc_popup_reg_shortcodes_vc');
	}
}



/* Shortcode implementation
-------------------------------------------------------------------- */

/*
[trx_popup id="unique_id" class="class_name" style="css_styles"]Et adipiscing integer, scelerisque pid, augue mus vel tincidunt porta[/trx_popup]
*/

if (!function_exists('seafood_company_sc_popup')) {	
	function seafood_company_sc_popup($atts, $content=null){	
		if (seafood_company_in_shortcode_blogger()) return '';
		extract(seafood_company_html_decode(shortcode_atts(array(
			// Common params
			"id" => "",
			"class" => "",
			"css" => "",
			"top" => "",
			"bottom" => "",
			"left" => "",
			"right" => ""
		), $atts)));
		$class .= ($class ? ' ' : '') . seafood_company_get_css_position_as_classes($top, $right, $bottom, $left);
		seafood_company_enqueue_popup('magnific');
		$output = '<div' . ($id ? ' id="'.esc_attr($id).'"' : '') 
				. ' class="sc_popup mfp-with-anim mfp-hide' . ($class ? ' '.esc_attr($class) : '') . '"'
				. ($css!='' ? ' style="'.esc_attr($css).'"' : '')
				. '>' 
				. do_shortcode($content) 
				. '</div>';
		return apply_filters('seafood_company_shortcode_output', $output, 'trx_popup', $atts, $content);
	}
    add_shortcode('trx_popup', 'seafood_company_sc_popup');
}



/* Register shortcode in the internal SC Builder
-------------------------------------------------------------------- */
if ( !function_exists( 'seafood_company_sc_popup_reg_shortcodes' ) ) {
	//add_action('seafood_company_action_shortcodes_list', 'seafood_company_sc_popup_reg_shortcodes');
	function seafood_company_sc_popup_reg_shortcodes() {
	
		seafood_company_sc_map("trx_popup", array(
			"title" => esc_html__("Popup window", 'trx_utils'),
			"desc" => wp_kses_data( __("Container for any html-block with desired class and style for popup window", 'trx_utils') ),
			"decorate" => true,
			"container" => true,
			"params" => array(
				"_content_" => array(
					"title" => esc_html__("Container content", 'trx_utils'),
					"desc" => wp_kses_data( __("Content for section container", 'trx_utils') ),
					"divider" => true,
					"rows" => 4,
					"value" => "",
					"type" => "textarea"
				),
				"top" => seafood_company_get_sc_param('top'),
				"bottom" => seafood_company_get_sc_param('bottom'),
				"left" => seafood_company_get_sc_param('left'),
				"right" => seafood_company_get_sc_param('right'),
				"id" => seafood_company_get_sc_param('id'),
				"class" => seafood_company_get_sc_param('class'),
				"css" => seafood_company_get_sc_param('css')
			)
		));
	}
}


/* Register shortcode in the VC Builder
-------------------------------------------------------------------- */
if ( !function_exists( 'seafood_company_sc_popup_reg_shortcodes_vc' ) ) {
	//add_action('seafood_company_action_shortcodes_list_vc', 'seafood_company_sc_popup_reg_shortcodes_vc');
	function seafood_company_sc_popup_reg_shortcodes_vc() {
	
		vc_map( array(
			"base" => "trx_popup",
			"name" => esc_html__("Popup window", 'trx_utils'),
			"description" => wp_kses_data( __("Container for any html-block with desired class and style for popup window", 'trx_utils') ),
			"category" => esc_html__('Content', 'trx_utils'),
			'icon' => 'icon_trx_popup',
			"class" => "trx_sc_collection trx_sc_popup",
			"content_element" => true,
			"is_container" => true,
			"show_settings_on_create" => true,
			"params" => array(
				seafood_company_get_vc_param('id'),
				seafood_company_get_vc_param('class'),
				seafood_company_get_vc_param('css'),
				seafood_company_get_vc_param('margin_top'),
				seafood_company_get_vc_param('margin_bottom'),
				seafood_company_get_vc_param('margin_left'),
				seafood_company_get_vc_param('margin_right')
			)
		) );
		
		class WPBakeryShortCode_Trx_Popup extends Seafood_Company_VC_ShortCodeCollection {}
	}
}
?>